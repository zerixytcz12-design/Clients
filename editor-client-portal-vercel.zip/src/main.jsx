import React, { useMemo, useState } from "react";
import { createRoot } from "react-dom/client";
import {
  ArrowRight, CheckCircle2, ChevronRight, Clock3, FileVideo2, FolderOpen,
  Home, Inbox, LogOut, Menu, MessageSquare, PackageOpen, Plus, Search,
  Settings, Sparkles, Upload, UserRound, X, CreditCard, CircleDollarSign,
  ExternalLink, Download, Check, AlertCircle
} from "lucide-react";
import "./styles.css";

const initialProjects = [
  {
    id: "#024",
    title: "Brawl Stars — Ranked Montage",
    type: "YouTube video",
    status: "Editing",
    progress: 68,
    deadline: "4. 10. 2026",
    price: 850,
    files: ["gameplay.mp4", "logo.png", "reference.mp4"],
    feedback: [
      { from: "Client", text: "V první části prosím trochu rychlejší střih.", time: "Před 2 h" }
    ]
  },
  {
    id: "#023",
    title: "Shorts — 3 Kills Challenge",
    type: "YouTube Short",
    status: "Review",
    progress: 92,
    deadline: "30. 9. 2026",
    price: 350,
    files: ["short_raw.mp4"],
    feedback: []
  }
];

const nav = [
  ["overview", "Přehled", Home],
  ["orders", "Zakázky", PackageOpen],
  ["messages", "Zprávy", MessageSquare],
  ["files", "Soubory", FolderOpen],
  ["settings", "Nastavení", Settings]
];

function App() {
  const [page, setPage] = useState("overview");
  const [mobileOpen, setMobileOpen] = useState(false);
  const [projects, setProjects] = useState(initialProjects);
  const [showOrder, setShowOrder] = useState(false);
  const [selected, setSelected] = useState(null);
  const [toast, setToast] = useState("");

  const total = useMemo(() => projects.reduce((a,p)=>a+p.price,0), [projects]);

  const notify = (msg) => {
    setToast(msg);
    setTimeout(()=>setToast(""), 2600);
  };

  const createOrder = (e) => {
    e.preventDefault();
    const form = new FormData(e.currentTarget);
    const title = form.get("title") || "Nová video zakázka";
    const type = form.get("type") || "YouTube video";
    const budget = Number(form.get("budget") || 0);
    const newProject = {
      id: `#${String(25 + projects.length).padStart(3,"0")}`,
      title, type, status:"New", progress:0,
      deadline: form.get("deadline") || "Dle dohody",
      price: budget,
      files: [],
      feedback:[]
    };
    setProjects([newProject, ...projects]);
    setShowOrder(false);
    setPage("orders");
    notify("Zakázka byla odeslána editorovi.");
  };

  return (
    <div className="app">
      <aside className={`sidebar ${mobileOpen ? "open":""}`}>
        <div className="brand">
          <div className="brandMark"><Sparkles size={18}/></div>
          <div><strong>KRYX</strong><span>CLIENT PORTAL</span></div>
          <button className="closeMobile" onClick={()=>setMobileOpen(false)}><X size={19}/></button>
        </div>

        <div className="clientCard">
          <div className="avatar">MK</div>
          <div><strong>Matěj K.</strong><span>Klient</span></div>
          <div className="online"></div>
        </div>

        <nav>
          {nav.map(([key,label,Icon]) => (
            <button key={key} className={page===key ? "active":""} onClick={()=>{setPage(key);setMobileOpen(false)}}>
              <Icon size={18}/><span>{label}</span>
            </button>
          ))}
        </nav>

        <div className="sidebarBottom">
          <div className="support">
            <div className="supportIcon"><MessageSquare size={16}/></div>
            <div><strong>Potřebuješ pomoc?</strong><span>Napiš editorovi</span></div>
          </div>
          <button className="logout" onClick={()=>notify("Demo: odhlášení je připravené pro backend.")}>
            <LogOut size={17}/> Odhlásit se
          </button>
        </div>
      </aside>

      <main className="main">
        <header className="topbar">
          <button className="mobileMenu" onClick={()=>setMobileOpen(true)}><Menu size={21}/></button>
          <div className="crumb"><span>Client Portal</span><ChevronRight size={15}/><strong>{nav.find(n=>n[0]===page)?.[1] || "Přehled"}</strong></div>
          <div className="topActions">
            <button className="iconBtn" onClick={()=>notify("Žádné nové notifikace.")}><Inbox size={18}/></button>
            <div className="topAvatar">MK</div>
          </div>
        </header>

        <div className="content">
          {page==="overview" && <Overview projects={projects} total={total} onNew={()=>setShowOrder(true)} onOpen={(p)=>setSelected(p)} />}
          {page==="orders" && <Orders projects={projects} onNew={()=>setShowOrder(true)} onOpen={(p)=>setSelected(p)} />}
          {page==="messages" && <Messages notify={notify}/>}
          {page==="files" && <Files projects={projects} notify={notify}/>}
          {page==="settings" && <SettingsPage notify={notify}/>}
        </div>
      </main>

      {selected && <ProjectModal project={selected} onClose={()=>setSelected(null)} notify={notify}/>}
      {showOrder && <OrderModal onClose={()=>setShowOrder(false)} onSubmit={createOrder}/>}
      {toast && <div className="toast"><CheckCircle2 size={18}/>{toast}</div>}
    </div>
  );
}

function Overview({projects,total,onNew,onOpen}) {
  const active=projects.filter(p=>p.status!=="Completed").length;
  return <div>
    <div className="hero">
      <div>
        <div className="eyebrow">VÍTEJ ZPĚT, MATĚJI</div>
        <h1>Tvoje videa,<br/><span>na jednom místě.</span></h1>
        <p>Objednávky, soubory, feedback a komunikace s editorem bez zbytečného chaosu.</p>
        <button className="primary" onClick={onNew}><Plus size={18}/> Nová zakázka</button>
      </div>
      <div className="heroOrb"><div><Sparkles size={34}/><strong>EDIT</strong><span>CREATE · REVIEW · DONE</span></div></div>
    </div>

    <div className="stats">
      <Stat icon={PackageOpen} label="Aktivní zakázky" value={active}/>
      <Stat icon={Clock3} label="Nejbližší deadline" value="30. 9." small/>
      <Stat icon={CircleDollarSign} label="Objednávky celkem" value={`${total.toLocaleString("cs-CZ")} Kč`} small/>
      <Stat icon={CheckCircle2} label="Dokončeno" value={projects.filter(p=>p.status==="Completed").length}/>
    </div>

    <SectionTitle title="Aktuální zakázky" action="Zobrazit vše" onClick={()=>document.querySelector('[data-nav="orders"]')}/>
    <div className="projectGrid">
      {projects.slice(0,3).map(p=><ProjectCard key={p.id} project={p} onOpen={onOpen}/>)}
    </div>

    <div className="bottomGrid">
      <div className="panel">
        <SectionTitle title="Jak to funguje"/>
        <div className="steps">
          <Step n="01" title="Pošli zadání" text="Vyplň brief a přidej materiály."/>
          <Step n="02" title="Editor pracuje" text="Sleduj průběh přímo v portálu."/>
          <Step n="03" title="Review & hotovo" text="Pošli feedback a schval finální verzi."/>
        </div>
      </div>
      <div className="panel accentPanel">
        <Sparkles size={21}/>
        <h3>Chceš další edit?</h3>
        <p>Vytvoř novou zakázku během pár minut.</p>
        <button className="ghostLight" onClick={onNew}>Objednat edit <ArrowRight size={16}/></button>
      </div>
    </div>
  </div>
}

function Stat({icon:Icon,label,value,small}) {
  return <div className="stat"><div className="statIcon"><Icon size={18}/></div><div><span>{label}</span><strong className={small?"small":""}>{value}</strong></div></div>
}
function SectionTitle({title,action,onClick}) {
  return <div className="sectionTitle"><h2>{title}</h2>{action&&<button onClick={onClick}>{action}<ArrowRight size={15}/></button>}</div>
}
function Step({n,title,text}) {
  return <div className="step"><div className="stepN">{n}</div><div><strong>{title}</strong><span>{text}</span></div></div>
}
function ProjectCard({project,onOpen}) {
  return <button className="projectCard" onClick={()=>onOpen(project)}>
    <div className="projectTop"><span className={`status ${project.status.toLowerCase()}`}>{project.status}</span><span>{project.id}</span></div>
    <div className="thumb"><FileVideo2 size={30}/><span>{project.type}</span></div>
    <h3>{project.title}</h3>
    <div className="progressRow"><span>Progress</span><strong>{project.progress}%</strong></div>
    <div className="progress"><i style={{width:`${project.progress}%`}}/></div>
    <div className="cardBottom"><span><Clock3 size={14}/> {project.deadline}</span><span>{project.price.toLocaleString("cs-CZ")} Kč</span></div>
  </button>
}

function Orders({projects,onNew,onOpen}) {
  const [filter,setFilter]=useState("All");
  const list=filter==="All"?projects:projects.filter(p=>p.status===filter);
  return <div>
    <PageHeader title="Moje zakázky" text="Přehled všech tvých projektů." button="Nová zakázka" onClick={onNew}/>
    <div className="filters">{["All","New","Editing","Review","Completed"].map(f=><button className={filter===f?"selected":""} key={f} onClick={()=>setFilter(f)}>{f==="All"?"Vše":f}</button>)}</div>
    <div className="ordersTable">
      <div className="tableHead"><span>Projekt</span><span>Stav</span><span>Progress</span><span>Deadline</span><span>Cena</span></div>
      {list.map(p=><button className="tableRow" key={p.id} onClick={()=>onOpen(p)}>
        <div><div className="miniThumb"><FileVideo2 size={17}/></div><div><strong>{p.title}</strong><span>{p.type} · {p.id}</span></div></div>
        <span className={`status ${p.status.toLowerCase()}`}>{p.status}</span>
        <div className="tableProgress"><span>{p.progress}%</span><div className="progress"><i style={{width:`${p.progress}%`}}/></div>
        <span>{p.deadline}</span><strong>{p.price.toLocaleString("cs-CZ")} Kč</strong>
      </button>)}
    </div>
  </div>
}

function PageHeader({title,text,button,onClick}) {
  return <div className="pageHeader"><div><div className="eyebrow">CLIENT PORTAL</div><h1>{title}</h1><p>{text}</p></div>{button&&<button className="primary" onClick={onClick}><Plus size={18}/>{button}</button>}</div>
}

function Messages({notify}) {
  const [msg,setMsg]=useState("");
  return <div>
    <PageHeader title="Zprávy" text="Komunikace s tvým editorem na jednom místě."/>
    <div className="chat">
      <div className="chatHead"><div className="avatar">KR</div><div><strong>Kryx — Editor</strong><span><i/> Online</span></div></div>
      <div className="chatBody">
        <div className="bubble editor">Ahoj! Tvůj edit #024 je momentálně na 68 %. Jakmile bude první verze hotová, pošlu ti ji sem. <small>10:42</small></div>
        <div className="bubble me">Super, díky! 🔥 <small>10:45</small></div>
        <div className="bubble editor">Není zač. Pokud budeš mít další reference nebo materiály, můžeš je přidat přímo k projektu. <small>10:46</small></div>
      </div>
      <form className="chatInput" onSubmit={e=>{e.preventDefault(); if(msg.trim()){notify("Zpráva odeslána.");setMsg("")}}}>
        <input value={msg} onChange={e=>setMsg(e.target.value)} placeholder="Napiš zprávu…"/>
        <button className="primary">Odeslat <ArrowRight size={16}/></button>
      </form>
    </div>
  </div>
}

function Files({projects,notify}) {
  const files=projects.flatMap(p=>p.files.map(f=>({name:f,project:p.title})));
  return <div>
    <PageHeader title="Soubory" text="Materiály, reference a exporty k tvým projektům."/>
    <div className="uploadBox" onClick={()=>notify("Demo: zde bude napojený cloud upload.")}>
      <div><Upload size={24}/></div><strong>Přetáhni soubory sem</strong><span>nebo klikni pro nahrání · MP4, MOV, PNG, JPG, ZIP</span>
    </div>
    <div className="fileList">
      {files.map((f,i)=><div className="fileItem" key={i}><div className="fileIcon"><FileVideo2 size={18}/></div><div><strong>{f.name}</strong><span>{f.project}</span></div><button onClick={()=>notify("Demo: download souboru.")}><Download size={17}/></button></div>)}
    </div>
  </div>
}

function SettingsPage({notify}) {
  return <div><PageHeader title="Nastavení" text="Správa profilu a preferencí."/>
    <div className="settingsGrid">
      <div className="panel formPanel"><h3>Profil</h3><label>Jméno<input defaultValue="Matěj K."/></label><label>E-mail<input defaultValue="matej@example.com"/></label><label>Discord / Instagram<input defaultValue="@matej"/></label><button className="primary" onClick={()=>notify("Nastavení uloženo.")}>Uložit změny</button></div>
      <div className="panel"><h3>Preference</h3><div className="toggleRow"><div><strong>E-mailová upozornění</strong><span>Informace o změnách zakázky</span></div><div className="toggle on"><i/></div></div><div className="toggleRow"><div><strong>Dark mode</strong><span>Moderní tmavé rozhraní</span></div><div className="toggle on"><i/></div></div></div>
    </div>
  </div>
}

function ProjectModal({project,onClose,notify}) {
  return <div className="overlay"><div className="modal projectModal"><button className="modalClose" onClick={onClose}><X/></button><div className="modalEyebrow">{project.id} · {project.type}</div><h2>{project.title}</h2><div className="modalStatus"><span className={`status ${project.status.toLowerCase()}`}>{project.status}</span><span>Deadline: {project.deadline}</span></div>
    <div className="bigProgress"><div><span>Progress projektu</span><strong>{project.progress}%</strong></div><div className="progress"><i style={{width:`${project.progress}%`}}/></div>
    <div className="modalGrid"><div className="panel"><h3>Materiály</h3>{project.files.length?<>{project.files.map(f=><div className="fileItem compact" key={f}><FileVideo2 size={16}/><span>{f}</span><Download size={15}/></div>)}</>:<p className="muted">Zatím žádné soubory.</p>}</div>
    <div className="panel"><h3>Feedback</h3>{project.feedback.length?project.feedback.map((f,i)=><div className="feedback" key={i}><strong>{f.from}</strong><span>{f.text}</span><small>{f.time}</small></div>):<p className="muted">Zatím žádný feedback.</p>}<button className="secondary" onClick={()=>notify("Demo: feedback formulář připraven.")}><MessageSquare size={15}/> Přidat feedback</button></div></div>
    <div className="modalFooter"><div><span>Cena zakázky</span><strong>{project.price.toLocaleString("cs-CZ")} Kč</strong></div><button className="primary" onClick={()=>notify("Demo: otevření platby.")}><CreditCard size={17}/> Zaplatit</button></div>
  </div></div>
}

function OrderModal({onClose,onSubmit}) {
  return <div className="overlay"><div className="modal orderModal"><button className="modalClose" onClick={onClose}><X/></button><div className="modalEyebrow">NEW PROJECT</div><h2>Objednat nový edit</h2><p className="modalLead">Vyplň základní informace. Editor se ti následně ozve s potvrzením a cenou.</p>
    <form onSubmit={onSubmit}>
      <div className="two"><label>Název projektu<input name="title" required placeholder="Např. Brawl Stars montage"/></label><label>Typ videa<select name="type"><option>YouTube video</option><option>YouTube Short</option><option>TikTok</option><option>Instagram Reel</option><option>Jiný edit</option></select></label></div>
      <div className="two"><label>Deadline<input name="deadline" type="date"/></label><label>Rozpočet (Kč)<input name="budget" type="number" min="0" placeholder="Např. 500"/></label></div>
      <label>Co chceš vytvořit?<textarea name="brief" rows="4" placeholder="Popiš styl, délku, efekty, titulky, hudbu, reference…"></textarea></label>
      <label>Reference / odkaz<input name="reference" placeholder="YouTube / TikTok / Google Drive odkaz"/></label>
      <div className="fakeUpload"><Upload size={19}/><span><strong>Přidat materiály</strong><small>Upload bude v produkci napojen na cloud storage</small></span><button type="button">Vybrat soubory</button></div>
      <div className="orderNote"><AlertCircle size={16}/> Toto je první demo verze. Platby a skutečný upload vyžadují backendové napojení.</div>
      <div className="formActions"><button type="button" className="secondary" onClick={onClose}>Zrušit</button><button className="primary" type="submit">Odeslat zakázku <ArrowRight size={16}/></button></div>
    </form>
  </div></div>
}

createRoot(document.getElementById("root")).render(<App />);