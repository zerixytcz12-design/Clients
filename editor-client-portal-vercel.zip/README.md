# KRYX Client Portal

Moderní první verze klientského portálu pro video editora.

## Spuštění lokálně

```bash
npm install
npm run dev
```

## Build pro Vercel

```bash
npm run build
```

Vercel:
- Framework: Vite
- Build Command: `npm run build`
- Output Directory: `dist`

## Co je v první verzi

- Dashboard klienta
- Přehled zakázek
- Filtrování zakázek
- Detail projektu
- Progress projektu
- Feedback
- Zprávy
- Soubory
- Nová zakázka / brief
- Nastavení profilu
- Responsive design pro PC, tablet a mobil
- Demo notifikace

## Důležité

Tato první verze je frontend/demo. Pro produkční použití je potřeba přidat backend:
- autentizaci
- databázi
- skutečný upload souborů
- oddělené účty klient/editor
- skutečný chat a feedback
- Stripe platby
- cloud storage
